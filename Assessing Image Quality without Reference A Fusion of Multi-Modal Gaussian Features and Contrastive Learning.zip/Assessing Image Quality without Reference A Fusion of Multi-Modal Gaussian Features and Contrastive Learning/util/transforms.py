import numpy as np

def crop_patches(image, patch_height, patch_width):
    h, w, c = image.shape
    patches = []
    for i in range(0, h, patch_height):
        for j in range(0, w, patch_width):
            patch = image[i:i+patch_height, j:j+patch_width]
            patches.append(patch)
    return np.array(patches)