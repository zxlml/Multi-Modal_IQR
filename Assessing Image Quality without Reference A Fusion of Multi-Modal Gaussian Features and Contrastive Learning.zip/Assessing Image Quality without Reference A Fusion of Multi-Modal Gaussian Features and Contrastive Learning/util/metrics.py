import numpy as np
from scipy.stats import spearmanr
from scipy.stats import pearsonr

def calculate_srocc(pred_scores, gt_scores):

    return spearmanr(pred_scores, gt_scores).correlation

def calculate_plcc(pred_scores, gt_scores):

    return pearsonr(pred_scores, gt_scores)[0]

def calculate_metrics(pred_scores, gt_scores):

    srocc = calculate_srocc(pred_scores, gt_scores)
    plcc = calculate_plcc(pred_scores, gt_scores)
    return {'SROCC': srocc, 'PLCC': plcc}