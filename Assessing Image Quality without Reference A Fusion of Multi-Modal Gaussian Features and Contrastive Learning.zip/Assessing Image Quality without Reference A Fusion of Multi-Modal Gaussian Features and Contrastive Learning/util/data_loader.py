import os
import pandas as pd
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader
from PIL import Image
import torchvision.transforms as T

class IQADataset(Dataset):
    def __init__(self, config, is_train=True, transform=None):
        self.config = config
        self.root = config.DATASET_ROOT
        self.dataset_name = config.DATASET_NAME
        self.is_train = is_train
        self.transform = transform

        self.image_paths, self.scores = self._load_data()

    def _load_data(self):
        csv_path = os.path.join(self.root, self.dataset_name, 'mos.csv')
        df = pd.read_csv(csv_path)
        
        image_dir = os.path.join(self.root, self.dataset_name, 'refimgs' if self.is_train else 'dstimgs')
        
        image_paths = [os.path.join(image_dir, fname) for fname in df['image_name']]
        scores = df['score'].values
        
        num_images = len(image_paths)
        split_idx = int(num_images * (1 - self.config.TEST_SPLIT_RATIO))
        
        if self.is_train:
            return image_paths[:split_idx], scores[:split_idx]
        else:
            return image_paths[split_idx:], scores[split_idx:]

    def __len__(self):
        return len(self.image_paths)

    def __getitem__(self, idx):
        img_path = self.image_paths[idx]
        score = self.scores[idx]
        
        image = Image.open(img_path).convert('RGB')
        
        if self.transform:
            image = self.transform(image)
            
        return image, torch.tensor(score, dtype=torch.float32)

def get_data_loaders(config):
    train_transform = T.Compose([
        T.RandomCrop(224),
        T.RandomHorizontalFlip(),
        T.ToTensor(),
        T.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])
    
    test_transform = T.Compose([
        T.CenterCrop(224),
        T.ToTensor(),
        T.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])

    train_dataset = IQADataset(config, is_train=True, transform=train_transform)
    test_dataset = IQADataset(config, is_train=False, transform=test_transform)

    train_loader = DataLoader(train_dataset, batch_size=config.BATCH_SIZE, shuffle=True, num_workers=4)
    test_loader = DataLoader(test_dataset, batch_size=1, shuffle=False, num_workers=4)

    return train_loader, test_loader