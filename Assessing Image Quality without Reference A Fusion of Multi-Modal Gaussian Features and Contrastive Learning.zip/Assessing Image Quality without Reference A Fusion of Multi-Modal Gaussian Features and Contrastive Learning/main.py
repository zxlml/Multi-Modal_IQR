import torch
import torch.nn as nn
import torch.optim as optim
from tqdm import tqdm
import logging
import wandb
import numpy as np

from config import *
from model.quality_model import QualityPredictor
from model.feature_extractor import MultiModalFeatureExtractor
from utils.data_loader import get_data_loaders
from utils.metrics import calculate_metrics

logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(levelname)s - %(message)s',
                    handlers=[
                        logging.FileHandler(f"{LOG_DIR}/training.log"),
                        logging.StreamHandler()
                    ])

def supervised_contrastive_loss(features, labels, tau=TEMPERATURE_TAU):
    batch_size = features.size(0)
    if batch_size == 0:
        return torch.tensor(0.0, requires_grad=True)

    features_norm = F.normalize(features, p=2, dim=1)
    similarity_matrix = torch.matmul(features_norm, features_norm.T) / tau
    labels = labels.unsqueeze(0).expand(batch_size, batch_size)
    positive_mask = (labels == labels.T).float()
    mask = torch.eye(batch_size, device=features.device).bool()
    similarity_matrix.masked_fill_(mask, -float('inf'))
    positive_mask.masked_fill_(mask, 0)
    numerator = torch.exp(similarity_matrix) * positive_mask
    numerator = numerator.sum(dim=1)
    denominator = torch.exp(similarity_matrix).sum(dim=1)
    loss = -torch.log(numerator / denominator + 1e-8)
    return loss.mean()

def train_one_epoch(model, dataloader, optimizer, device, feature_extractor, epoch):
    model.train()
    total_loss = 0
    for images, scores in tqdm(dataloader, desc=f"Epoch {epoch+1}/{EPOCHS} - Training"):
        images = images.to(device)
        scores = scores.to(device)
        fake_labels = torch.bucketize(scores, bins=5, out_of_range=False)
        _, projected_features = model(images)
        contrast_loss = supervised_contrastive_loss(projected_features, fake_labels)
        pred_scores, _ = model(images)
        regression_loss = F.l1_loss(pred_scores.squeeze(), scores)
        loss = contrast_loss + regression_loss
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        
        total_loss += loss.item()
        
        if USE_WANDB:
            wandb.log({
                "train/loss": loss.item(),
                "train/contrast_loss": contrast_loss.item(),
                "train/regression_loss": regression_loss.item()
            })
            
    avg_loss = total_loss / len(dataloader)
    logging.info(f"Average training loss for epoch {epoch+1}: {avg_loss:.4f}")
    return avg_loss

def evaluate(model, dataloader, device, feature_extractor):
    model.eval()
    all_preds = []
    all_gts = []
    
    with torch.no_grad():
        for images, scores in tqdm(dataloader, desc="Evaluating"):
            images = images.to(device)
            scores = scores.to(device)

            pred_scores, _ = model(images)
            
            all_preds.extend(pred_scores.cpu().numpy())
            all_gts.extend(scores.cpu().numpy())
            
    metrics = calculate_metrics(np.array(all_preds), np.array(all_gts))
    logging.info(f"Evaluation Metrics: SROCC={metrics['SROCC']:.4f}, PLCC={metrics['PLCC']:.4f}")
    
    if USE_WANDB:
        wandb.log({
            "eval/SROCC": metrics['SROCC'],
            "eval/PLCC": metrics['PLCC']
        })
        
    return metrics

def main():
    if USE_WANDB:
        wandb.init(project=WANDB_PROJECT_NAME, config=config.__dict__)
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    logging.info(f"Using device: {device}")
    
    feature_extractor = MultiModalFeatureExtractor(config)
    train_loader, test_loader = get_data_loaders(config)
    
    model = QualityPredictor(config).to(device)
    optimizer = optim.AdamW(model.parameters(), lr=LEARNING_RATE, weight_decay=WEIGHT_DECAY)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=EPOCHS, eta_min=0)
    
    best_srocc = 0.0
    for epoch in range(EPOCHS):
        train_one_epoch(model, train_loader, optimizer, device, feature_extractor, epoch)
        scheduler.step()
        
        metrics = evaluate(model, test_loader, device, feature_extractor)
        
        if metrics['SROCC'] > best_srocc:
            best_srocc = metrics['SROCC']
            torch.save(model.state_dict(), "best_model.pth")
            logging.info("New best model saved!")
            
    logging.info("Training finished.")

if __name__ == '__main__':
    main()