import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.models as models

class Encoder(nn.Module):

    def __init__(self, backbone='resnet50', pretrained=True):
        super(Encoder, self).__init__()
        if backbone == 'resnet50':
            self.model = models.resnet50(pretrained=pretrained)

            self.model = nn.Sequential(*list(self.model.children())[:-1])
            self.out_dim = 2048 
        else:
            raise ValueError(f"Unsupported backbone: {backbone}")

    def forward(self, x):

        return self.model(x)

class Projector(nn.Module):
    def __init__(self, in_dim, out_dim=128):
        super(Projector, self).__init__()
        self.fc = nn.Sequential(
            nn.Linear(in_dim, 512),
            nn.ReLU(),
            nn.Linear(512, out_dim)
        )

    def forward(self, x):

        x = F.normalize(x, p=2, dim=1)
        return self.fc(x)

class QualityPredictor(nn.Module):
    def __init__(self, config):
        super(QualityPredictor, self).__init__()
        self.encoder = Encoder(backbone=config.ENCODER_BACKBONE)
        self.projector = Projector(in_dim=self.encoder.out_dim, out_dim=config.PROJECTION_DIM)

        self.regressor = nn.Sequential(
            nn.Linear(config.PROJECTION_DIM, 64),
            nn.ReLU(),
            nn.Linear(64, 1)
        )

    def forward(self, x):
        features = self.encoder(x)
        projected_features = self.projector(features)
        quality_score = self.regressor(projected_features)
        return quality_score, projected_features