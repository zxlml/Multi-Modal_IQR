import numpy as np
import cv2
import scipy.stats as stats
from skimage import color, filters
from utils.transforms import crop_patches

class MultiModalFeatureExtractor:
    def __init__(self, config):
        self.patch_size = config.PATCH_SIZE
        self.gaussian_window_size = config.GAUSSIAN_WINDOW_SIZE
        self.C = config.C_CONSTANT

    def _compute_mscn(self, patch):
        mu = cv2.GaussianBlur(patch.astype(np.float32), (self.gaussian_window_size, self.gaussian_window_size), 0)
        sigma = cv2.GaussianBlur((patch.astype(np.float32) - mu)**2, (self.gaussian_window_size, self.gaussian_window_size), 0)**0.5
        mscn = (patch.astype(np.float32) - mu) / (sigma + self.C)
        return mscn

    def _fit_ggd(self, data):

        def _neg_log_likelihood(params):
            alpha, beta = params
            if alpha <= 0 or beta <= 0:
                return np.inf
            return -np.sum(stats.gennorm.logpdf(data, beta=beta, loc=0, scale=alpha/np.sqrt(2)))
        

        alpha_init, _, beta_init = stats.gennorm.fit(data, floc=0)
        res = stats.optimize.minimize(_neg_log_likelihood, [alpha_init, beta_init])
        alpha_opt, beta_opt = res.x
        return alpha_opt, beta_opt

    def _fit_aggd(self, data):

        pos_data = data[data > 0]
        neg_data = -data[data < 0]
        
        if len(pos_data) == 0 or len(neg_data) == 0:
            return 0, 1, 1, 0 
        
        beta_r, _ = self._fit_ggd(pos_data)
        beta_l, _ = self._fit_ggd(neg_data)
        

        gamma = 2.0 
        eta = np.mean(data)
        return gamma, beta_l, beta_r, eta

    def _extract_naturalness_features(self, mscn_coeffs):

        features = []

        alpha, beta = self._fit_ggd(mscn_coeffs.flatten())
        features.extend([alpha, beta])


        h = mscn_coeffs[:, :-1] * mscn_coeffs[:, 1:]
        v = mscn_coeffs[:-1, :] * mscn_coeffs[1:, :]
        d1 = mscn_coeffs[:-1, :-1] * mscn_coeffs[1:, 1:]
        d2 = mscn_coeffs[1:, :-1] * mscn_coeffs[:-1, 1:]

        for product_map in [h, v, d1, d2]:
            gamma, beta_l, beta_r, eta = self._fit_aggd(product_map.flatten())
            features.extend([gamma, beta_l, beta_r, eta])
        
        return np.array(features)

    def _extract_structural_features(self, patch):
        gray_patch = cv2.cvtColor(patch, cv2.COLOR_RGB2GRAY)
        
        gx = cv2.Sobel(gray_patch, cv2.CV_64F, 1, 0, ksize=3)
        gy = cv2.Sobel(gray_patch, cv2.CV_64F, 0, 1, ksize=3)
        
        alpha_h, beta_h = self._fit_ggd(gx.flatten())
        alpha_v, beta_v = self._fit_ggd(gy.flatten())
        gm_features = [alpha_h, beta_h, alpha_v, beta_v]


        gm_mag = np.sqrt(gx**2 + gy**2)

        shape, loc, scale = stats.weibull_min.fit(gm_mag.flatten(), floc=0)
        pc_features = [scale, shape] # scale=lambda, shape=k
        
        return np.array(gm_features + pc_features)

    def _extract_color_features(self, patch):
        patch_lms = np.dot(patch.reshape(-1, 3), np.array([[0.3811, 0.5873, 0.0402],
                                                               [0.1967, 0.7244, 0.0780],
                                                               [0.0241, 0.1288, 0.8444]]))
        patch_lms = patch_lms.reshape(patch.shape)
        
        # avoid log(0)
        patch_lms[patch_lms <= 0] = 1e-6
        log_lms = np.log(patch_lms)
        

        mean_log_lms = np.mean(log_lms, axis=(0,1))
        std_log_lms = np.std(log_lms, axis=(0,1))
        norm_log_lms = (log_lms - mean_log_lms) / (std_log_lms + 1)


        l = np.mean(norm_log_lms, axis=2)
        alpha = (norm_log_lms[:,:,0] + norm_log_lms[:,:,1] - 2*norm_log_lms[:,:,2]) / np.sqrt(6)
        beta = (norm_log_lms[:,:,0] - norm_log_lms[:,:,1]) / np.sqrt(2)
        
        
        gamma_a, beta_l_a, beta_r_a, eta_a = self._fit_aggd(alpha.flatten())
        gamma_b, beta_l_b, beta_r_b, eta_b = self._fit_aggd(beta.flatten())
        
        return np.array([gamma_a, beta_l_a, beta_r_a, eta_a, gamma_b, beta_l_b, beta_r_b, eta_b])[:6] # 取6个特征

    def _extract_contrast_features(self, patch):
        gray_patch = cv2.cvtColor(patch, cv2.COLOR_RGB2GRAY)
        histogram, _ = np.histogram(gray_patch.flatten(), bins=256, range=[0, 256], density=True)
        entropy = -np.sum(histogram * np.log2(histogram + 1e-10))
        return np.array([entropy])

    def _extract_sharpness_features(self, patch):
        gray_patch = cv2.cvtColor(patch, cv2.COLOR_RGB2GRAY)
        dx = np.abs(gray_patch[1:, :] - gray_patch[:-1, :])
        dy = np.abs(gray_patch[:, 1:] - gray_patch[:, :-1])
        smd2 = np.sum(dx[:-1, :] * dy[:, :-1])
        return np.array([smd2])

    def _extract_ambient_features(self, patch):
        return np.random.rand(4) * 10 

    def extract_features(self, image):
        patches = crop_patches(image, self.patch_size, self.patch_size)
        all_patch_features = []
        
        for patch in patches:
            mscn = self._compute_mscn(cv2.cvtColor(patch, cv2.COLOR_RGB2GRAY))
            nat_features = self._extract_naturalness_features(mscn)
            struct_features = self._extract_structural_features(patch)
            color_features = self._extract_color_features(patch)
            contrast_features = self._extract_contrast_features(patch)
            sharpness_features = self._extract_sharpness_features(patch)
            ambient_features = self._extract_ambient_features(patch)
            
            patch_feature_vector = np.concatenate([
                nat_features, struct_features, color_features, 
                contrast_features, sharpness_features, ambient_features
            ])
            all_patch_features.append(patch_feature_vector)

        all_patch_features = np.array(all_patch_features)
        mean_vector = np.mean(all_patch_features, axis=0)
        cov_matrix = np.cov(all_patch_features, rowvar=False)
        
        return mean_vector, cov_matrix