import os


#  LIVE/refimgs/, LIVE/dstimgs/, LIVE/mos.csv
DATASET_ROOT = os.path.expanduser("~/datasets/IQA") 
# 'LIVE', 'CSIQ', 'TID2013', 'KADID10K', 'LIVEC', 'KONIQ', 'LIVEFB' 
DATASET_NAME = 'LIVE' 


PATCH_SIZE = 96
GAUSSIAN_WINDOW_SIZE = 7 
C_CONSTANT = 1 


ENCODER_BACKBONE = 'resnet50' 
PROJECTION_DIM = 128 


LEARNING_RATE = 2e-5
WEIGHT_DECAY = 1e-2
BATCH_SIZE = 4
EPOCHS = 150
TEMPERATURE_TAU = 0.1 
NUM_CROPS = 8 


USE_WANDB = True
WANDB_PROJECT_NAME = "NR-IQA-Project"
LOG_DIR = "logs"


TEST_SPLIT_RATIO = 0.2 